(function crashes() {
  var storage = navigator.getDeviceStorage("crashes");
  var crashReportBaseURL = "https://crash-stats.mozilla.com/report/index/";

  if (!storage) {
    console.error("Unable to access crashes from devicestorage!");
    return;
  }

  var list = document.getElementById("crash-list");
  var cursor = storage.enumerate();
  cursor.onsuccess = function() {
    if (cursor.result) {
      var name = this.result.name;

      if (name.indexOf('submitted') !== -1) {
        var crashReportTxt = name.replace('submitted/', '');
        var crashReportID = crashReportTxt.replace('.txt', '');
        var crashReportURL = crashReportBaseURL + crashReportID;
        var crashReportLink = "<a href=\"" + crashReportURL +
          "\" target=\"_blank\">" + crashReportID + "</a>";

        list.innerHTML += "<li>" + crashReportLink + "</li>";
      }

      cursor.continue();
    }
  };
  cursor.onerror = function() {
    console.error("Error getting crashes files: " + this.error.name);
  };
})();
