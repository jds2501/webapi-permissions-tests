﻿function handlePushMessage(message) {
	console.log('push message received');
	console.log('endpoint : ' + message.pushEndPoint);
	console.log(message);
}

function registerEndPoint() {
	var outputResult = document.getElementById('endPointRegisteredResult');
	var request = navigator.push.register();

	request.onsuccess = function(e) {
		var endPoint = e.target.result;

		outputResult.textContent = 'End point registered: ' + endPoint;
	};

	request.onerror = function(e) {
		outputResult.textContent = 'Error : " + err.target.error.name;
	};
}

function initialize() {
	navigator.mozSetMessageHandler('push', handlePushMessage);

	document.getElementById('registerPushEndPoint').onclick = registerEndPoint;
}

window.addEventListener("DOMContentLoaded", initialize);
