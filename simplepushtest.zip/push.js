﻿function handlePushMessage(message) {
	console.log('push message received');
	console.log('endpoint: ' + message.pushEndpoint);
	console.log('version: ' + message.version);
}

function registerEndPoint() {
	var outputResult = document.getElementById('endPointRegisteredResult');
	var request = navigator.push.register();

	console.log('navigator.push.register is called');

	request.onsuccess = function(e) {
		var endPoint = e.target.result;
		console.log('register success fired with endpoint: ' + endPoint);

		outputResult.textContent = 'End point registered: ' + endPoint;
	};

	request.onerror = function(err) {
		console.log('register onerror fired with: ' + err.target.error.name);
		outputResult.textContent = 'Error : ' + err.target.error.name;
	};
}

function initialize() {
	navigator.mozSetMessageHandler('push', handlePushMessage);

	document.getElementById('registerPushEndPoint').onclick = registerEndPoint;
}

window.addEventListener("DOMContentLoaded", initialize);
