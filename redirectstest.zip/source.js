﻿function initialize() {
	document.getElementById('redirectionByLocation').onclick = function () {
		window.location = 'https://www.google.com';
	}
}

window.addEventListener('DOMContentLoaded', initialize);
