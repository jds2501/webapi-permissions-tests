function contactTest() {
        var contact = new mozContact();
        contact.init({name: "Tom"});
        var request = navigator.mozContacts.save(contact);
        request.onsuccess = function() {alert("success");};
        request.onerror = function() {alert("error")};
}

function deviceStorageTest() {
        var deviceStorage = navigator.getDeviceStorage('pictures');
        deviceStorage.enumerateEditable();
}

document.getElementById('contacts').onclick = contactTest;
document.getElementById('device').onclick = deviceStorageTest;
